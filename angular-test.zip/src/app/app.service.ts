import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ClientData } from './clientData';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  getDashboardData():Observable<ClientData[]> {
    return this.http.get<ClientData[]>('assets/CandidateSample.json');
  }
}
