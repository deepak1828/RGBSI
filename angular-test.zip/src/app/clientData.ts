export class ClientData {
  CandidateName: string;
  BirthDate: string;
  SSN: number;
  Email: string;
  VendorName: string;
  IsActive: string;
}
