import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { AppService } from '../app.service';
import { ClientData } from '../clientData';

import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  gridData: ClientData[];
  searchCandidate;

  displayedColumns: string[] = ['CandidateName', 'BirthDate', 'SSN', 'Email', 'VendorName'];
  dataSource: MatTableDataSource<ClientData>;

  enableCardView: boolean = true;
  enableTableView: boolean = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _appService: AppService) { }

  ngOnInit(){
    this.getData();
  }

  getData() {
    this._appService.getDashboardData().subscribe((res) => {
      this.gridData = res;

      this.dataSource = new MatTableDataSource(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    });
  }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  toggleView() {
    this.enableCardView = !this.enableCardView;
    this.enableTableView = !this.enableTableView;
  }

}
